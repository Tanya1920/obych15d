document.addEventListener('click', function(){
    document.querySelector('.switcher').classList.toggle('toggled');
})